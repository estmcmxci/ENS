# Podcasts & Videos

### Podcasts

* ****[**Early with ENS Podcast**](https://open.spotify.com/episode/6DoSULJSKHjUhujODHd5Wq) - "_Nick Johnson on founding and building ENS_" &#x20;
* ****[**The Defiant Podcast**](https://open.spotify.com/episode/1QA3O4SPdmdo4Pc34JWFOB) - "_Nick Johnson of ENS: 'We Want to be the naming system for every digital resource in the world._'"&#x20;

### Youtube

See the official [ENS YouTube](https://www.youtube.com/c/ENSdomains) Channel.

* [**ENS on Bankless** ](https://www.youtube.com/watch?v=jwadHC5ha-E)- _"Nick Johnson and Brantly Millegan discuss the ENS airdrop on Bankless."_

****
