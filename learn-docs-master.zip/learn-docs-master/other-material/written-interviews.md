# Written Interviews

This is a collection of written interviews.

* [Interview with ENS team (Virgil Griffith)](https://medium.com/the-ethereum-name-service/interview-with-ens-team-virgil-griffith-4dd1dcf9d13f)
* [Interview with ENS team (Nick Johnson)](https://medium.com/the-ethereum-name-service/interview-with-ens-team-nick-johnson-d98fb296d228)
