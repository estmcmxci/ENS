## ENS Name
An ENS Name is a human-readable name that you can use to reference your Ethereum address, function as your decentralized identity, store metadata, and even direct payments cryptocurrencies outside of the Ethereum blockchain!

## Gas
Gas refers to the unit that measures the amount of computational effort required to execute specific operations on the Ethereum network.

## Cryptocurrency
Cryptocurrencies are a digital store of value that is securely verified by a network of computers that are validated using cryptography. Cryptocurrencies provide a transparent and secure way to represent value.
