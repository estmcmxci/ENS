# Registrations & Extensions

{% content-ref url="how-long-will-it-take-for-my-transaction-to-finish.md" %}
[how-long-will-it-take-for-my-transaction-to-finish.md](how-long-will-it-take-for-my-transaction-to-finish.md)
{% endcontent-ref %}

{% content-ref url="how-much-does-it-cost-to-register-an-ens-name.md" %}
[how-much-does-it-cost-to-register-an-ens-name.md](how-much-does-it-cost-to-register-an-ens-name.md)
{% endcontent-ref %}

{% content-ref url="../ens-names/registrations-and-renewals/why-are-there-3-steps-for-registration.md" %}
[why-are-there-3-steps-for-registration.md](../ens-names/registrations-and-renewals/why-are-there-3-steps-for-registration.md)
{% endcontent-ref %}

{% content-ref url="what-is-a-premium-auction.md" %}
[what-is-a-premium-auction.md](what-is-a-premium-auction.md)
{% endcontent-ref %}

{% content-ref url="../ens-names/registrations-and-renewals/what-is-a-grace-period.md" %}
[what-is-a-grace-period.md](../ens-names/registrations-and-renewals/what-is-a-grace-period.md)
{% endcontent-ref %}

{% content-ref url="../ens-names/registrations-and-renewals/how-do-i-use-an-ens-name-after-purchasing-it-on-a-secondary-marketplace.md" %}
[how-do-i-use-an-ens-name-after-purchasing-it-on-a-secondary-marketplace.md](../ens-names/registrations-and-renewals/how-do-i-use-an-ens-name-after-purchasing-it-on-a-secondary-marketplace.md)
{% endcontent-ref %}
