# Wallets

{% content-ref url="what-is-a-wallet.md" %}
[what-is-a-wallet.md](what-is-a-wallet.md)
{% endcontent-ref %}

{% content-ref url="../../wallets/what-are-gas-fees.md" %}
[what-are-gas-fees.md](../../wallets/what-are-gas-fees.md)
{% endcontent-ref %}

{% content-ref url="what-is-a-private-key.md" %}
[what-is-a-private-key.md](what-is-a-private-key.md)
{% endcontent-ref %}

{% content-ref url="how-do-transactions-work.md" %}
[how-do-transactions-work.md](how-do-transactions-work.md)
{% endcontent-ref %}
