# Names & Records

{% content-ref url="../ens-names/names-and-records/why-isnt-the-resolver-set-to-my-address.md" %}
[why-isnt-the-resolver-set-to-my-address.md](../ens-names/names-and-records/why-isnt-the-resolver-set-to-my-address.md)
{% endcontent-ref %}

{% content-ref url="../ens-names/names-and-records/how-do-i-set-a-primary-name-for-my-wallet.md" %}
[how-do-i-set-a-primary-name-for-my-wallet.md](../ens-names/names-and-records/how-do-i-set-a-primary-name-for-my-wallet.md)
{% endcontent-ref %}

{% content-ref url="what-is-a-primary-name.md" %}
[what-is-a-primary-name.md](what-is-a-primary-name.md)
{% endcontent-ref %}

{% content-ref url="broken-reference" %}
[Broken link](broken-reference)
{% endcontent-ref %}

{% content-ref url="how-do-i-add-a-non-eth-address-to-my-ens-name.md" %}
[how-do-i-add-a-non-eth-address-to-my-ens-name.md](how-do-i-add-a-non-eth-address-to-my-ens-name.md)
{% endcontent-ref %}

{% content-ref url="what-are-text-records-and-how-do-they-work.md" %}
[what-are-text-records-and-how-do-they-work.md](what-are-text-records-and-how-do-they-work.md)
{% endcontent-ref %}
