# Using ENS Names

{% content-ref url="../ens-names/using-ens-names/what-can-i-use-an-ens-name-for.md" %}
[what-can-i-use-an-ens-name-for.md](../ens-names/using-ens-names/what-can-i-use-an-ens-name-for.md)
{% endcontent-ref %}
